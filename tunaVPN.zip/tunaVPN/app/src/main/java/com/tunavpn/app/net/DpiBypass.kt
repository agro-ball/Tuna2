package com.tunavpn.app.net

import com.tunavpn.app.Method
import com.tunavpn.app.Strategies
import java.io.OutputStream
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap

/** Запоминает, какой способ сработал для сервера в режиме «Авто». */
object AutoState {
    private val idx = ConcurrentHashMap<String, Int>()

    fun methodFor(key: String): Method {
        val order = Strategies.AUTO_ORDER
        return order[(idx[key] ?: 0) % order.size]
    }

    fun failed(key: String) {
        idx[key] = ((idx[key] ?: 0) + 1) % Strategies.AUTO_ORDER.size
    }
}

/**
 * Способы отправки первого пакета (ClientHello / HTTP-запрос), которые работают
 * без root: деление на части, TTL-трюк, срочный байт, дробление TLS-записи.
 */
object DpiBypass {

    fun send(sock: Socket, out: OutputStream, data: ByteArray, method: Method) {
        sock.tcpNoDelay = true
        if (TlsUtil.isClientHello(data)) {
            sendTls(sock, out, data, method)
        } else if (TlsUtil.isHttp(data)) {
            sendHttp(sock, out, data, method)
        } else {
            plain(out, data)
        }
    }

    private fun sendTls(sock: Socket, out: OutputStream, data: ByteArray, method: Method) {
        val sni = TlsUtil.findSni(data)
        // смещение в середине имени сайта (или запасное, если SNI не нашли)
        val mid = if (sni != null) sni.start + sni.len / 2 else 40
        val q = (mid - 5).coerceAtLeast(1)
        when (method) {
            Method.SPLIT -> split(out, data, 1)
            Method.SPLIT2 -> split(out, data, 2)
            Method.SPLIT_SNI, Method.AUTO -> split(out, data, mid)
            Method.MULTI -> {
                val end = if (sni != null) sni.start + sni.len else mid + 4
                multi(out, data, intArrayOf(1, mid, end))
            }
            Method.TLSREC -> plain(out, TlsUtil.splitRecord(data, q))
            Method.TLSREC1 -> plain(out, TlsUtil.splitRecord(data, 1))
            Method.TLSREC_SPLIT -> split(out, TlsUtil.splitRecord(data, q), 5 + q)
            Method.TLSREC_DISORDER -> disorder(sock, out, TlsUtil.splitRecord(data, q), 5 + q, false)
            Method.OOB -> oob(sock, out, data, mid)
            Method.SPLIT_OOB -> oob(sock, out, data, 1)
            Method.DISORDER -> disorder(sock, out, data, mid, false)
            Method.DISORDER_OOB -> disorder(sock, out, data, mid, true)
        }
    }

    private fun sendHttp(sock: Socket, out: OutputStream, data: ByteArray, method: Method) {
        val h = TlsUtil.findHttpHost(data)
        val pos = if (h > 0) h + 1 else 3
        when (method) {
            Method.OOB, Method.SPLIT_OOB -> oob(sock, out, data, pos)
            Method.DISORDER, Method.TLSREC_DISORDER -> disorder(sock, out, data, pos, false)
            Method.DISORDER_OOB -> disorder(sock, out, data, pos, true)
            Method.MULTI -> multi(out, data, intArrayOf(1, pos, pos + 4))
            else -> split(out, data, pos)
        }
    }

    private fun plain(out: OutputStream, data: ByteArray) {
        out.write(data)
        out.flush()
    }

    private fun split(out: OutputStream, data: ByteArray, at: Int) {
        if (data.size < 2) return plain(out, data)
        val pos = at.coerceIn(1, data.size - 1)
        out.write(data, 0, pos)
        out.flush()
        pause()
        out.write(data, pos, data.size - pos)
        out.flush()
    }

    private fun oob(sock: Socket, out: OutputStream, data: ByteArray, at: Int) {
        if (data.size < 2) return plain(out, data)
        val pos = at.coerceIn(1, data.size - 1)
        out.write(data, 0, pos)
        out.flush()
        pause()
        try {
            sock.sendUrgentData('a'.code)
        } catch (_: Exception) {
        }
        pause()
        out.write(data, pos, data.size - pos)
        out.flush()
    }

    /** Несколько частей подряд: режем по позициям. */
    private fun multi(out: OutputStream, data: ByteArray, cuts: IntArray) {
        if (data.size < 4) return plain(out, data)
        var prev = 0
        for (c in cuts.sorted()) {
            if (prev + 1 > data.size - 1) break
            val pos = c.coerceIn(prev + 1, data.size - 1)
            if (pos <= prev || pos >= data.size) continue
            out.write(data, prev, pos - prev)
            out.flush()
            pause()
            prev = pos
        }
        out.write(data, prev, data.size - prev)
        out.flush()
    }

    /**
     * Первая часть уходит с TTL=1 и не доходит до DPI/сервера, вторая — нормально.
     * Потерянную первую часть ядро само перешлёт позже: так порядок частей нарушается.
     */
    private fun disorder(sock: Socket, out: OutputStream, data: ByteArray, at: Int, withOob: Boolean) {
        if (data.size < 2) return plain(out, data)
        val pos = at.coerceIn(1, data.size - 1)
        val old = SockUtil.getTtl(sock) ?: 64
        SockUtil.setTtl(sock, 1)
        out.write(data, 0, pos)
        out.flush()
        pause()
        SockUtil.setTtl(sock, old)
        if (withOob) {
            try {
                sock.sendUrgentData('a'.code)
            } catch (_: Exception) {
            }
            pause()
        }
        out.write(data, pos, data.size - pos)
        out.flush()
    }

    private fun pause() {
        try {
            Thread.sleep(3)
        } catch (_: InterruptedException) {
        }
    }
}
