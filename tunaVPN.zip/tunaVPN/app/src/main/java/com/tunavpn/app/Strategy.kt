package com.tunavpn.app

enum class Method {
    AUTO, SPLIT, SPLIT2, SPLIT_SNI, MULTI, TLSREC, TLSREC1, TLSREC_SPLIT,
    OOB, SPLIT_OOB, DISORDER, DISORDER_OOB, TLSREC_DISORDER
}

data class Strategy(
    val id: String,
    val name: String,
    val description: String,
    val method: Method
)

object Strategies {

    val ALL: List<Strategy> = listOf(
        Strategy("auto", "Авто", "Сам подбирает рабочий способ для каждого сервера", Method.AUTO),
        Strategy("split_sni", "Split SNI", "Режет запрос на два пакета посреди имени сайта", Method.SPLIT_SNI),
        Strategy("multi", "Multi-split", "Режет запрос на три части: начало, имя сайта, остаток", Method.MULTI),
        Strategy("tlsrec", "TLS Record", "Дробит TLS-запись на две, имя сайта не видно целиком", Method.TLSREC),
        Strategy("tlsrec1", "TLS Record 1", "Выделяет первый байт в отдельную TLS-запись", Method.TLSREC1),
        Strategy("tlsrec_split", "TLS Record + Split", "Дробит запись и отправляет её частями", Method.TLSREC_SPLIT),
        Strategy("tlsrec_disorder", "TLS Record + Disorder", "Дробит запись и меняет порядок частей", Method.TLSREC_DISORDER),
        Strategy("oob", "OOB (имя сайта)", "Вставляет «срочный» байт посреди имени сайта", Method.OOB),
        Strategy("split_oob", "Split 1 + OOB", "Отделяет первый байт и вставляет «срочный» байт", Method.SPLIT_OOB),
        Strategy("disorder", "Disorder", "Меняет порядок частей запроса, старт чуть медленнее", Method.DISORDER),
        Strategy("disorder_oob", "Disorder + OOB", "Меняет порядок частей и вставляет «срочный» байт", Method.DISORDER_OOB),
        Strategy("split", "Split 1", "Отделяет первый байт запроса", Method.SPLIT),
        Strategy("split2", "Split 2", "Отделяет первые два байта запроса", Method.SPLIT2)
    )

    /** Порядок перебора для режима «Авто». */
    val AUTO_ORDER: List<Method> = listOf(
        Method.SPLIT_SNI, Method.TLSREC, Method.TLSREC_SPLIT, Method.MULTI,
        Method.OOB, Method.DISORDER, Method.TLSREC_DISORDER, Method.SPLIT_OOB,
        Method.SPLIT, Method.DISORDER_OOB, Method.TLSREC1, Method.SPLIT2
    )

    fun byId(id: String): Strategy = ALL.firstOrNull { it.id == id } ?: ALL[0]
}
