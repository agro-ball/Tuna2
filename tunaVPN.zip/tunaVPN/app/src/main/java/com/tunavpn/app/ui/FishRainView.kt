package com.tunavpn.app.ui

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup
import com.tunavpn.app.R
import java.util.Random
import kotlin.math.sin

/**
 * Фон: много маленьких рыбок из эмблемы плывут сверху вниз.
 * Рыбки разложены по «дорожкам» с одинаковой скоростью внутри дорожки, поэтому не налезают друг на друга.
 */
class FishRainView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private class Fish(
        val laneX: Float,
        var y: Float,
        val heightPx: Float,
        val speed: Float,     // пикселей в секунду
        val amp: Float,       // раскачивание вбок
        val freq: Float,
        val phase: Float,
        val alpha: Int,
        val span: Float       // длина пути дорожки, для зацикливания
    )

    private val dp = resources.displayMetrics.density
    private val bmp: Bitmap? = BitmapFactory.decodeResource(resources, R.drawable.fish)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val fishes = ArrayList<Fish>()
    private val m = Matrix()
    private var last = 0L
    private var time = 0f
    private var margin = 0f

    init {
        isClickable = false
        isFocusable = false
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        fishes.clear()
        if (w <= 0 || h <= 0) return
        val rnd = Random(11)
        margin = 70f * dp
        val lanes = maxOf(3, (w / (88f * dp)).toInt())
        val laneW = w.toFloat() / lanes
        for (i in 0 until lanes) {
            val count = 3 + (i % 2)                       // 3 или 4 рыбки на дорожке
            val span = h + 2 * margin
            val gap = span / count
            val speed = (16f + rnd.nextFloat() * 22f) * dp // у каждой дорожки своя скорость
            val size = (32f + rnd.nextFloat() * 28f) * dp
            val offset = rnd.nextFloat() * gap
            for (k in 0 until count) {
                fishes.add(
                    Fish(
                        laneX = laneW * (i + 0.5f),
                        y = -margin + offset + k * gap,
                        heightPx = size,
                        speed = speed,
                        amp = (6f + rnd.nextFloat() * 9f) * dp,
                        freq = 0.5f + rnd.nextFloat() * 0.7f,
                        phase = rnd.nextFloat() * 6.28f,
                        alpha = 22 + rnd.nextInt(26),
                        span = span
                    )
                )
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        val b = bmp ?: return
        val now = System.nanoTime()
        val dt = if (last == 0L) 0f else ((now - last) / 1_000_000_000f).coerceAtMost(0.05f)
        last = now
        time += dt

        val bw = b.width.toFloat()
        val bh = b.height.toFloat()
        for (f in fishes) {
            f.y += f.speed * dt
            if (f.y > height + margin) f.y -= f.span

            val sway = sin(time * f.freq + f.phase)
            val x = f.laneX + sway * f.amp
            val s = f.heightPx / bh

            m.reset()
            m.postTranslate(-bw / 2f, -bh / 2f)
            m.postScale(s, s)
            // рыба на картинке смотрит вверх-вправо — разворачиваем носом вниз и чуть покачиваем
            m.postRotate(135f + sway * 9f)
            m.postTranslate(x, f.y)
            paint.alpha = f.alpha
            canvas.drawBitmap(b, m, paint)
        }
        postInvalidateOnAnimation()
    }

    companion object {
        /** Добавляет рыбопад позади содержимого экрана. */
        fun attach(activity: Activity) {
            val content = activity.findViewById<ViewGroup>(android.R.id.content)
            content.addView(
                FishRainView(activity), 0,
                ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
        }
    }
}
