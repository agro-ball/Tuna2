package com.tunavpn.app.net

import java.net.URL
import java.security.SecureRandom
import javax.net.ssl.HttpsURLConnection

/** DNS поверх HTTPS: запросы приложений не видны провайдеру и не подменяются. */
object Doh {

    private val endpoints = listOf("https://1.1.1.1/dns-query", "https://8.8.8.8/dns-query")

    /** Если DoH недоступен, на минуту переходим на обычный DNS, чтобы не ждать таймаутов. */
    @Volatile private var failUntil = 0L

    fun isDown(): Boolean = System.currentTimeMillis() < failUntil

    /** Имя из DNS-запроса (для журнала). */
    fun queryName(q: ByteArray): String {
        val sb = StringBuilder()
        var p = 12
        while (p < q.size) {
            val l = q[p].toInt() and 0xFF
            if (l == 0 || p + 1 + l > q.size) break
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(q, p + 1, l, Charsets.US_ASCII))
            p += l + 1
        }
        return sb.toString()
    }

    /** Отправляет готовый DNS-запрос (wire format), возвращает ответ или null. */
    fun resolve(query: ByteArray): ByteArray? {
        if (isDown()) return null
        for (url in endpoints) {
            try {
                val c = URL(url).openConnection() as HttpsURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 1500
                c.readTimeout = 2500
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/dns-message")
                c.setRequestProperty("Accept", "application/dns-message")
                c.outputStream.use { it.write(query) }
                if (c.responseCode == 200) {
                    val body = c.inputStream.use { it.readBytes() }
                    if (body.size >= 12) return body
                }
                c.disconnect()
            } catch (_: Exception) {
            }
        }
        failUntil = System.currentTimeMillis() + 60_000
        return null
    }

    /** Тип запроса (1 = A, 28 = AAAA) или -1. */
    fun queryType(q: ByteArray): Int {
        if (q.size < 17) return -1
        var p = 12
        while (p < q.size && q[p].toInt() != 0) p += (q[p].toInt() and 0xFF) + 1
        p += 1
        if (p + 2 > q.size) return -1
        return ((q[p].toInt() and 0xFF) shl 8) or (q[p + 1].toInt() and 0xFF)
    }

    /**
     * Пустой успешный ответ. На AAAA отвечаем так, чтобы приложения не пытались
     * ходить по IPv6, который туннель не обрабатывает.
     */
    fun emptyAnswer(q: ByteArray): ByteArray {
        var p = 12
        while (p < q.size && q[p].toInt() != 0) p += (q[p].toInt() and 0xFF) + 1
        p += 1 + 4
        val r = q.copyOf(minOf(p, q.size))
        r[2] = 0x81.toByte()
        r[3] = 0x80.toByte()
        for (i in 6..11) r[i] = 0
        return r
    }

    /** Находит IPv4-адрес имени через DoH, null если не вышло. */
    fun lookupA(host: String): String? {
        try {
            val q = java.io.ByteArrayOutputStream()
            val id = ByteArray(2).also { SecureRandom().nextBytes(it) }
            q.write(id)
            q.write(byteArrayOf(0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00))
            for (label in host.split('.')) {
                q.write(label.length)
                q.write(label.toByteArray(Charsets.US_ASCII))
            }
            q.write(0)
            q.write(byteArrayOf(0x00, 0x01, 0x00, 0x01))
            val r = resolve(q.toByteArray()) ?: return null
            return parseFirstA(r)
        } catch (_: Exception) {
            return null
        }
    }

    private fun skipName(b: ByteArray, start: Int): Int {
        var p = start
        while (p < b.size) {
            val l = b[p].toInt() and 0xFF
            if (l == 0) return p + 1
            if (l and 0xC0 == 0xC0) return p + 2
            p += l + 1
        }
        return b.size
    }

    private fun parseFirstA(b: ByteArray): String? {
        val qd = ((b[4].toInt() and 0xFF) shl 8) or (b[5].toInt() and 0xFF)
        val an = ((b[6].toInt() and 0xFF) shl 8) or (b[7].toInt() and 0xFF)
        var p = 12
        repeat(qd) { p = skipName(b, p) + 4 }
        repeat(an) {
            if (p + 10 > b.size) return null
            p = skipName(b, p)
            if (p + 10 > b.size) return null
            val type = ((b[p].toInt() and 0xFF) shl 8) or (b[p + 1].toInt() and 0xFF)
            val rdLen = ((b[p + 8].toInt() and 0xFF) shl 8) or (b[p + 9].toInt() and 0xFF)
            p += 10
            if (type == 1 && rdLen == 4 && p + 4 <= b.size) {
                return "${b[p].toInt() and 0xFF}.${b[p + 1].toInt() and 0xFF}." +
                    "${b[p + 2].toInt() and 0xFF}.${b[p + 3].toInt() and 0xFF}"
            }
            p += rdLen
        }
        return null
    }
}
