package com.tunavpn.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.tunavpn.app.service.TunaVpnService
import com.tunavpn.app.ui.FishRainView
import com.tunavpn.app.ui.PowerButtonView

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var power: PowerButtonView
    private lateinit var tvTimer: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvCurrent: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var lastRunning: Boolean? = null

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 500)
        }
    }

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) startTunnel()
    }

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        requestVpnThenStart()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        FishRainView.attach(this)
        prefs = Prefs(this)

        power = findViewById(R.id.powerButton)
        tvTimer = findViewById(R.id.tvTimer)
        tvStatus = findViewById(R.id.tvStatus)
        tvCurrent = findViewById(R.id.tvCurrent)

        setupSplash(savedInstanceState == null)

        power.setOnClickListener {
            if (TunaVpnService.isRunning) stopTunnel() else beginStart()
        }
        findViewById<View>(R.id.btnProtocols).setOnClickListener {
            startActivity(Intent(this, ProtocolsActivity::class.java))
        }
        findViewById<View>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        refresh(force = true, animate = false)
    }

    // ───────────────────────────── заставка ─────────────────────────────

    private fun setupSplash(play: Boolean) {
        val splash = findViewById<View>(R.id.splash)
        if (!play) {
            splash.visibility = View.GONE
            return
        }
        val emblem = findViewById<ImageView>(R.id.emblem)
        emblem.alpha = 0f
        emblem.scaleX = 0.92f
        emblem.scaleY = 0.92f
        emblem.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(1000).withEndAction {
            emblem.animate().alpha(0f).setStartDelay(650).setDuration(800).withEndAction {
                splash.animate().alpha(0f).setDuration(350).withEndAction {
                    splash.visibility = View.GONE
                }.start()
            }.start()
        }.start()
    }

    // ───────────────────────────── запуск / остановка ─────────────────────────────

    private fun beginStart() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            requestVpnThenStart()
        }
    }

    private fun requestVpnThenStart() {
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermission.launch(intent) else startTunnel()
    }

    private fun startTunnel() {
        startForegroundService(Intent(this, TunaVpnService::class.java).setAction(TunaVpnService.ACTION_START))
        handler.postDelayed({ refresh() }, 300)
    }

    private fun stopTunnel() {
        startService(Intent(this, TunaVpnService::class.java).setAction(TunaVpnService.ACTION_STOP))
        handler.postDelayed({ refresh() }, 300)
    }

    // ───────────────────────────── обновление экрана ─────────────────────────────

    private fun refresh(force: Boolean = false, animate: Boolean = true) {
        val running = TunaVpnService.isRunning
        if (force || lastRunning != running) {
            lastRunning = running
            power.setOn(running, animate)
            tvStatus.text = if (running) "Подключено" else "Нажми, чтобы включить"
            tvTimer.alpha = if (running) 1f else 0.35f
        }
        tvTimer.text = if (running) {
            val s = (SystemClock.elapsedRealtime() - TunaVpnService.startedAt) / 1000
            "%02d:%02d:%02d".format(s / 3600, (s / 60) % 60, s % 60)
        } else {
            "00:00:00"
        }
    }

    override fun onResume() {
        super.onResume()
        tvCurrent.text = Strategies.byId(prefs.strategyId).name
        refresh(force = true, animate = false)
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }
}
