package com.tunavpn.app.net

/** Адреса серверов Telegram (IPv4). Соединения к ним перехватываются без настройки прокси. */
object TelegramRanges {

    private class Net(val base: Int, val mask: Int)

    private fun net(a: Int, b: Int, c: Int, d: Int, bits: Int): Net {
        val ip = (a shl 24) or (b shl 16) or (c shl 8) or d
        val mask = if (bits == 0) 0 else -1 shl (32 - bits)
        return Net(ip and mask, mask)
    }

    private val nets = listOf(
        net(149, 154, 160, 0, 20),
        net(91, 108, 4, 0, 22),
        net(91, 108, 8, 0, 22),
        net(91, 108, 12, 0, 22),
        net(91, 108, 16, 0, 22),
        net(91, 108, 20, 0, 22),
        net(91, 108, 56, 0, 22),
        net(95, 161, 64, 0, 20),
        net(185, 76, 151, 0, 24),
        net(109, 239, 140, 0, 24)
    )

    fun contains(ip: ByteArray): Boolean {
        if (ip.size != 4) return false
        val v = ((ip[0].toInt() and 0xFF) shl 24) or ((ip[1].toInt() and 0xFF) shl 16) or
            ((ip[2].toInt() and 0xFF) shl 8) or (ip[3].toInt() and 0xFF)
        for (n in nets) if ((v and n.mask) == n.base) return true
        return false
    }
}
