package com.tunavpn.app.net

import android.net.VpnService
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * UDP из туннеля:
 *  - порт 53 (DNS) отвечаем сами через DoH (или напрямую, если DoH выключен);
 *  - порт 443 (QUIC) отклоняем сразу — приложения переходят на TCP, где работает обход;
 *  - остальной UDP пробрасываем как есть.
 */
class UdpRelay(
    private val vpn: VpnService,
    private val dohEnabled: () -> Boolean,
    private val writeTun: (ByteArray) -> Unit,
    private val log: (String) -> Unit
) {
    private class Key(val srcPort: Int, val dstIp: String, val dstPort: Int) {
        override fun equals(other: Any?) =
            other is Key && other.srcPort == srcPort && other.dstIp == dstIp && other.dstPort == dstPort
        override fun hashCode() = (srcPort * 31 + dstIp.hashCode()) * 31 + dstPort
    }

    private class Sess(val sock: DatagramSocket) {
        @Volatile var last = System.currentTimeMillis()
    }

    private val pool = Executors.newCachedThreadPool()
    private val sessions = ConcurrentHashMap<Key, Sess>()

    fun handle(pkt: ByteArray) {
        try {
            val ipHL = PacketUtils.ipHeaderLen(pkt)
            val srcIp = PacketUtils.ipSrc(pkt)
            val dstIp = PacketUtils.ipDst(pkt)
            val srcPort = PacketUtils.srcPort(pkt, ipHL)
            val dstPort = PacketUtils.dstPort(pkt, ipHL)
            val payload = PacketUtils.udpPayload(pkt, ipHL)

            when (dstPort) {
                53 -> pool.execute { dns(srcIp, dstIp, srcPort, payload) }
                443 -> writeTun(PacketUtils.buildIcmpPortUnreachable(pkt))
                else -> forward(srcIp, dstIp, srcPort, dstPort, payload)
            }
        } catch (e: Exception) {
            log("UDP: ${e.message}")
        }
    }

    private fun dns(srcIp: ByteArray, dstIp: ByteArray, srcPort: Int, query: ByteArray) {
        if (query.size < 12) return
        val name = Doh.queryName(query)
        var answer: ByteArray? = null
        var how = ""
        if (Doh.queryType(query) == 28) {
            answer = Doh.emptyAnswer(query)
            how = "ipv4"
        } else if (dohEnabled()) {
            answer = Doh.resolve(query)
            if (answer != null) how = "doh"
        }
        if (answer == null) {
            answer = plainDns(dstIp, query)
            how = if (answer != null) "udp" else "НЕТ ОТВЕТА"
        }
        if (how == "ipv4") {
            // ответы на AAAA не засоряют журнал
        } else {
            log("DNS $name [$how]")
        }
        if (answer == null) return
        writeTun(PacketUtils.buildUdp(dstIp, srcIp, 53, srcPort, answer))
    }

    private fun plainDns(server: ByteArray, query: ByteArray): ByteArray? {
        var s: DatagramSocket? = null
        return try {
            s = DatagramSocket()
            vpn.protect(s)
            s.soTimeout = 3000
            s.send(DatagramPacket(query, query.size, InetAddress.getByAddress(server), 53))
            val buf = ByteArray(4096)
            val p = DatagramPacket(buf, buf.size)
            s.receive(p)
            buf.copyOf(p.length)
        } catch (_: Exception) {
            null
        } finally {
            try { s?.close() } catch (_: Exception) {}
        }
    }

    private fun forward(srcIp: ByteArray, dstIp: ByteArray, srcPort: Int, dstPort: Int, payload: ByteArray) {
        val dstStr = PacketUtils.ipString(dstIp)
        val key = Key(srcPort, dstStr, dstPort)
        var sess = sessions[key]
        if (sess == null) {
            val sock = DatagramSocket()
            vpn.protect(sock)
            sess = Sess(sock)
            sessions[key] = sess
            val s = sess
            pool.execute {
                val buf = ByteArray(65535)
                try {
                    while (true) {
                        val p = DatagramPacket(buf, buf.size)
                        s.sock.receive(p)
                        s.last = System.currentTimeMillis()
                        writeTun(PacketUtils.buildUdp(dstIp, srcIp, dstPort, srcPort, buf.copyOf(p.length)))
                    }
                } catch (_: Exception) {
                } finally {
                    sessions.remove(key, s)
                }
            }
        }
        sess.last = System.currentTimeMillis()
        try {
            sess.sock.send(DatagramPacket(payload, payload.size, InetAddress.getByAddress(dstIp), dstPort))
        } catch (_: Exception) {
            sessions.remove(key)
            try { sess.sock.close() } catch (_: Exception) {}
        }
    }

    fun cleanup() {
        val now = System.currentTimeMillis()
        val it = sessions.entries.iterator()
        while (it.hasNext()) {
            val e = it.next()
            if (now - e.value.last > 40_000) {
                it.remove()
                try { e.value.sock.close() } catch (_: Exception) {}
            }
        }
    }

    fun shutdown() {
        for (s in sessions.values) {
            try { s.sock.close() } catch (_: Exception) {}
        }
        sessions.clear()
        pool.shutdownNow()
    }
}
