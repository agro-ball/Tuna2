package com.tunavpn.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import com.tunavpn.app.Prefs

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!Prefs(context).autostart) return
        // без выданного ранее разрешения VPN автозапуск невозможен
        if (VpnService.prepare(context) != null) return
        val i = Intent(context, TunaVpnService::class.java).setAction(TunaVpnService.ACTION_START)
        context.startForegroundService(i)
    }
}
