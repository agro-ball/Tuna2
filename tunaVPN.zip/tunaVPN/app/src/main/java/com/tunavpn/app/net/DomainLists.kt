package com.tunavpn.app.net

import android.content.Context
import java.io.BufferedReader
import java.io.InputStreamReader

object DomainLists {

    @Volatile private var include: Set<String> = emptySet()
    @Volatile private var exclude: Set<String> = emptySet()

    fun load(context: Context) {
        include = loadAsset(context, "lists/list-general.txt") + loadAsset(context, "lists/list-google.txt")
        exclude = loadAsset(context, "lists/list-exclude.txt")
    }

    private fun loadAsset(context: Context, path: String): Set<String> = try {
        val set = HashSet<String>()
        context.assets.open(path).use { stream ->
            BufferedReader(InputStreamReader(stream)).forEachLine { line ->
                val t = line.trim()
                if (t.isNotEmpty() && !t.startsWith("#")) set.add(t.lowercase())
            }
        }
        set
    } catch (_: Exception) {
        emptySet()
    }

    private fun matches(set: Set<String>, host: String): Boolean {
        val h = host.lowercase()
        if (h in set) return true
        var i = h.indexOf('.')
        while (i >= 0) {
            if (h.substring(i + 1) in set) return true
            i = h.indexOf('.', i + 1)
        }
        return false
    }

    fun shouldBypass(host: String): Boolean {
        if (matches(exclude, host)) return false
        return matches(include, host)
    }
}
