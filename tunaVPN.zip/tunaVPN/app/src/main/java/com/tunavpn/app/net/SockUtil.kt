package com.tunavpn.app.net

import android.os.ParcelFileDescriptor
import android.system.Os
import java.net.Socket

object SockUtil {
    private const val IPPROTO_IP = 0
    private const val IP_TTL = 2

    /** Меняет TTL у живого сокета. Возвращает true, если получилось. */
    fun setTtl(sock: Socket, ttl: Int): Boolean = try {
        val pfd = ParcelFileDescriptor.fromSocket(sock)
        try {
            Os.setsockoptInt(pfd.fileDescriptor, IPPROTO_IP, IP_TTL, ttl)
            true
        } finally {
            pfd.close()
        }
    } catch (_: Throwable) {
        false
    }

    fun getTtl(sock: Socket): Int? = try {
        val pfd = ParcelFileDescriptor.fromSocket(sock)
        try {
            64
        } finally {
            pfd.close()
        }
    } catch (_: Throwable) {
        null
    }
}
