package com.tunavpn.app.net

import android.net.VpnService
import com.tunavpn.app.Method
import com.tunavpn.app.Strategy
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Random
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * Минимальный TCP между туннелем и реальными серверами.
 *
 * Клиент (приложение) говорит с нами «по-настоящему» через TUN: мы отвечаем на SYN,
 * подтверждаем данные по порядку и режем ответы сервера на сегменты по MSS с учётом
 * окна клиента. Первый пакет к серверу (ClientHello / HTTP) уходит через DpiBypass.
 *
 * Потери пакетов внутри устройства практически исключены, поэтому повторной отправки
 * (retransmit) здесь нет: вместо неё работает контроль окна.
 */
class TcpRelay(
    private val vpn: VpnService,
    private val strategy: () -> Strategy,
    private val domainOnly: () -> Boolean,
    private val tgDirect: () -> Boolean,
    private val writeTun: (ByteArray) -> Unit,
    private val log: (String) -> Unit
) {
    private companion object {
        const val MASK = 0xFFFFFFFFL
        const val MSS = 1400
        const val RCV_WND = 65535
        const val IDLE_MS = 300_000L
    }

    private data class Key(val srcPort: Int, val dstIp: String, val dstPort: Int)

    private class Chunk(val data: ByteArray?, val fin: Boolean, val poison: Boolean)

    private class Session(
        val key: Key,
        val clientIp: ByteArray,
        val serverIp: ByteArray,
        val clientPort: Int,
        val serverPort: Int
    ) {
        val lock = ReentrantLock()
        val cond = lock.newCondition()
        val queue = LinkedBlockingQueue<Chunk>()
        val queued = AtomicInteger(0)

        @Volatile var connected = false
        @Volatile var closed = false
        @Volatile var sndNext = 0L
        @Volatile var sndUna = 0L
        @Volatile var rcvNext = 0L
        @Volatile var peerWindow = 65535
        @Volatile var socket: Socket? = null
        @Volatile var lastActive = System.currentTimeMillis()
        @Volatile var clientFin = false
        @Volatile var finSent = false
        @Volatile var usedAuto = false
        @Volatile var autoKey = ""
        @Volatile var gotData = false
        @Volatile var viaTg = false
    }

    private val pool = Executors.newCachedThreadPool()
    private val watchdog = Executors.newSingleThreadScheduledExecutor()
    private val sessions = ConcurrentHashMap<Key, Session>()
    private val rnd = Random()

    // ───────────────────────── входящие пакеты из TUN ─────────────────────────

    fun handle(pkt: ByteArray) {
        try {
            process(pkt)
        } catch (e: Exception) {
            log("TCP: ${e.javaClass.simpleName} ${e.message}")
        }
    }

    private fun process(pkt: ByteArray) {
        val ipHL = PacketUtils.ipHeaderLen(pkt)
        if (ipHL < 20 || pkt.size < ipHL + 20) return

        val srcIp = PacketUtils.ipSrc(pkt)
        val dstIp = PacketUtils.ipDst(pkt)
        val srcPort = PacketUtils.srcPort(pkt, ipHL)
        val dstPort = PacketUtils.dstPort(pkt, ipHL)
        val seq = PacketUtils.tcpSeq(pkt, ipHL)
        val ack = PacketUtils.tcpAck(pkt, ipHL)
        val flags = PacketUtils.tcpFlags(pkt, ipHL)
        val window = PacketUtils.tcpWindow(pkt, ipHL)
        val payload = PacketUtils.tcpPayload(pkt, ipHL)

        val key = Key(srcPort, PacketUtils.ipString(dstIp), dstPort)
        val s = sessions[key]

        val isSyn = (flags and PacketUtils.FLAG_SYN) != 0
        val isAck = (flags and PacketUtils.FLAG_ACK) != 0
        val isFin = (flags and PacketUtils.FLAG_FIN) != 0
        val isRst = (flags and PacketUtils.FLAG_RST) != 0

        if (isSyn && !isAck) {
            if (s != null) return // повторный SYN: соединение уже устанавливается
            val ns = Session(key, srcIp, dstIp, srcPort, dstPort)
            ns.rcvNext = (seq + 1) and MASK
            sessions[key] = ns
            try {
                pool.execute { connect(ns) }
            } catch (_: Exception) {
                sessions.remove(key, ns)
            }
            return
        }

        if (s == null) {
            if (!isRst && (payload.isNotEmpty() || isFin)) {
                val rst = if (isAck) {
                    PacketUtils.buildTcp(dstIp, srcIp, dstPort, srcPort, ack, 0, PacketUtils.FLAG_RST, 0)
                } else {
                    PacketUtils.buildTcp(
                        dstIp, srcIp, dstPort, srcPort, 0,
                        (seq + payload.size + (if (isFin) 1 else 0)) and MASK,
                        PacketUtils.FLAG_RST or PacketUtils.FLAG_ACK, 0
                    )
                }
                writeTun(rst)
            }
            return
        }

        if (isRst) {
            close(s, false)
            return
        }
        if (!s.connected) return

        s.lastActive = System.currentTimeMillis()
        if (isAck) onAck(s, ack, window)
        if (payload.isNotEmpty()) onData(s, seq, payload)
        if (isFin) onFin(s, (seq + payload.size) and MASK)
    }

    private fun onAck(s: Session, ack: Long, window: Int) {
        s.lock.withLock {
            val inflight = (s.sndNext - s.sndUna) and MASK
            val adv = (ack - s.sndUna) and MASK
            if (adv <= inflight) s.sndUna = ack
            s.peerWindow = window
            s.cond.signalAll()
        }
        if (s.finSent && s.clientFin && s.sndUna == s.sndNext) close(s, false)
    }

    private fun onData(s: Session, seq: Long, payload: ByteArray) {
        s.lock.withLock {
            var accepted: ByteArray? = null
            val diff = (seq - s.rcvNext) and MASK
            if (diff == 0L) {
                accepted = payload
            } else if (diff > 0x80000000L) {
                // повторная отправка уже принятых данных: берём только новый хвост
                val overlap = (s.rcvNext - seq) and MASK
                if (overlap < payload.size) accepted = payload.copyOfRange(overlap.toInt(), payload.size)
            }
            if (accepted != null) {
                s.rcvNext = (s.rcvNext + accepted.size) and MASK
                s.queued.addAndGet(accepted.size)
                s.queue.add(Chunk(accepted, false, false))
            }
        }
        sendAck(s)
    }

    private fun onFin(s: Session, finSeq: Long) {
        s.lock.withLock {
            if (finSeq == s.rcvNext && !s.clientFin) {
                s.clientFin = true
                s.rcvNext = (s.rcvNext + 1) and MASK
                s.queue.add(Chunk(null, true, false))
            }
        }
        sendAck(s)
        if (s.finSent && s.clientFin && s.sndUna == s.sndNext) close(s, false)
    }

    // ───────────────────────── соединение с сервером ─────────────────────────

    private fun connect(s: Session) {
        val sock = Socket()
        val tg = tgDirect() && TelegramRanges.contains(s.serverIp)
        try {
            vpn.protect(sock)
            sock.tcpNoDelay = true
            if (tg) {
                // Telegram: отдаём соединение локальному обходу, первыми байтами сообщаем настоящий адрес
                sock.connect(InetSocketAddress("127.0.0.1", TelegramWsProxy.PORT), 3000)
                val pre = ByteArray(6)
                s.serverIp.copyInto(pre, 0)
                pre[4] = ((s.serverPort shr 8) and 0xFF).toByte()
                pre[5] = (s.serverPort and 0xFF).toByte()
                sock.getOutputStream().write(pre)
                s.viaTg = true
            } else {
                sock.connect(InetSocketAddress(s.key.dstIp, s.key.dstPort), 7000)
            }
        } catch (e: Exception) {
            log("✕ ${s.key.dstIp}:${s.key.dstPort} (${e.javaClass.simpleName})")
            try { sock.close() } catch (_: Exception) {}
            s.closed = true
            sessions.remove(s.key, s)
            writeTun(
                PacketUtils.buildTcp(
                    s.serverIp, s.clientIp, s.serverPort, s.clientPort, 0, s.rcvNext,
                    PacketUtils.FLAG_RST or PacketUtils.FLAG_ACK, 0
                )
            )
            return
        }

        s.socket = sock
        val isn = rnd.nextLong() and MASK
        s.sndNext = (isn + 1) and MASK
        s.sndUna = s.sndNext
        s.connected = true

        writeTun(
            PacketUtils.buildTcp(
                s.serverIp, s.clientIp, s.serverPort, s.clientPort, isn, s.rcvNext,
                PacketUtils.FLAG_SYN or PacketUtils.FLAG_ACK, RCV_WND,
                options = PacketUtils.mssOption(MSS)
            )
        )

        try {
            pool.execute { writerLoop(s) }
            pool.execute { readerLoop(s) }
        } catch (_: Exception) {
            close(s, true)
        }
    }

    /** Клиент → сервер: данные по порядку, первый пакет — через обход. */
    private fun writerLoop(s: Session) {
        val sock = s.socket ?: return
        try {
            val out = sock.getOutputStream()
            var first = true
            while (true) {
                val c = s.queue.take()
                if (c.poison) return
                if (c.fin) {
                    try { sock.shutdownOutput() } catch (_: Exception) {}
                    return
                }
                var data = c.data ?: continue
                val before = s.queued.getAndAdd(-data.size)
                var finAfter = false

                if (first) {
                    first = false
                    if (s.serverPort == 443 && data.size >= 5 && data[0] == 0x16.toByte()) {
                        // ClientHello может прийти в нескольких пакетах — собираем целиком
                        val need = 5 + TlsUtil.recordLen(data)
                        val parts = ArrayList<ByteArray>()
                        parts.add(data)
                        var have = data.size
                        while (have < need && have < 20_000) {
                            val nx = s.queue.poll(250, TimeUnit.MILLISECONDS) ?: break
                            if (nx.poison) return
                            if (nx.fin) { finAfter = true; break }
                            val nd = nx.data ?: continue
                            s.queued.addAndGet(-nd.size)
                            parts.add(nd)
                            have += nd.size
                        }
                        if (parts.size > 1) {
                            val all = ByteArray(have)
                            var o = 0
                            for (p in parts) { p.copyInto(all, o); o += p.size }
                            data = all
                        }
                    }
                    sendFirst(s, sock, out, data)
                } else {
                    out.write(data)
                }

                if (finAfter) {
                    try { sock.shutdownOutput() } catch (_: Exception) {}
                    return
                }
                // освободили место в буфере — сообщаем клиенту новое окно
                if (before > 32_768) sendAck(s)
            }
        } catch (_: Exception) {
            close(s, true)
        }
    }

    private fun sendFirst(s: Session, sock: Socket, out: java.io.OutputStream, data: ByteArray) {
        if (s.viaTg) {
            out.write(data)
            return
        }
        val port = s.serverPort
        val applicable = (port == 443 && TlsUtil.isClientHello(data)) || (port == 80 && TlsUtil.isHttp(data))
        if (!applicable) {
            out.write(data)
            return
        }
        val sni = if (port == 443) TlsUtil.findSni(data) else null
        if (domainOnly() && (sni == null || !DomainLists.shouldBypass(sni.host))) {
            out.write(data)
            return
        }

        val strat = strategy()
        val key = sni?.host ?: s.key.dstIp
        s.autoKey = key
        s.usedAuto = strat.method == Method.AUTO
        val method = if (s.usedAuto) AutoState.methodFor(key) else strat.method
        log("${sni?.host ?: s.key.dstIp}:$port → ${method.name.lowercase()}")
        DpiBypass.send(sock, out, data, method)

        if (s.usedAuto) {
            // если сервер молчит 8 секунд — этот способ не подошёл, в следующий раз возьмём другой
            try {
                watchdog.schedule({
                    if (!s.gotData && !s.closed) {
                        AutoState.failed(s.autoKey)
                        log("✕ ${s.autoKey}: нет ответа, пробую другой способ")
                        close(s, true)
                    }
                }, 8, TimeUnit.SECONDS)
            } catch (_: Exception) {
            }
        }
    }

    /** Сервер → клиент: режем на сегменты по MSS и ждём окно клиента. */
    private fun readerLoop(s: Session) {
        val sock = s.socket ?: return
        val buf = ByteArray(16384)
        try {
            val inp = sock.getInputStream()
            while (true) {
                val n = try {
                    inp.read(buf)
                } catch (_: Exception) {
                    -1
                }
                if (n < 0) {
                    if (!s.gotData && s.usedAuto && !s.closed) {
                        AutoState.failed(s.autoKey)
                        log("✕ ${s.autoKey}: соединение сброшено, пробую другой способ")
                        close(s, true) // RST: приложение переподключится
                        return
                    }
                    break
                }
                if (!s.gotData && s.autoKey.isNotEmpty()) log("✓ ${s.autoKey} отвечает")
                s.gotData = true
                s.lastActive = System.currentTimeMillis()
                if (!sendData(s, buf, n)) {
                    close(s, true)
                    return
                }
            }
        } catch (_: Exception) {
        }
        sendFin(s)
    }

    private fun sendData(s: Session, buf: ByteArray, n: Int): Boolean {
        var off = 0
        while (off < n) {
            val len = minOf(MSS, n - off)
            var seq = 0L
            var waited = 0L
            s.lock.withLock {
                while (true) {
                    if (s.closed) return false
                    val inflight = (s.sndNext - s.sndUna) and MASK
                    if (inflight == 0L || inflight + len <= s.peerWindow) break
                    s.cond.await(250, TimeUnit.MILLISECONDS)
                    waited += 250
                    if (waited > 90_000) return false
                }
                seq = s.sndNext
                s.sndNext = (s.sndNext + len) and MASK
            }
            writeTun(
                PacketUtils.buildTcp(
                    s.serverIp, s.clientIp, s.serverPort, s.clientPort,
                    seq, s.rcvNext, PacketUtils.FLAG_PSH or PacketUtils.FLAG_ACK,
                    currentWindow(s), buf.copyOfRange(off, off + len)
                )
            )
            off += len
        }
        return true
    }

    private fun sendFin(s: Session) {
        if (s.closed || s.finSent) return
        var seq = 0L
        s.lock.withLock {
            seq = s.sndNext
            s.sndNext = (s.sndNext + 1) and MASK
            s.finSent = true
        }
        writeTun(
            PacketUtils.buildTcp(
                s.serverIp, s.clientIp, s.serverPort, s.clientPort,
                seq, s.rcvNext, PacketUtils.FLAG_FIN or PacketUtils.FLAG_ACK, currentWindow(s)
            )
        )
        if (s.clientFin && s.sndUna == s.sndNext) close(s, false)
    }

    private fun currentWindow(s: Session) = (RCV_WND - s.queued.get()).coerceIn(0, 65535)

    private fun sendAck(s: Session) {
        writeTun(
            PacketUtils.buildTcp(
                s.serverIp, s.clientIp, s.serverPort, s.clientPort,
                s.sndNext, s.rcvNext, PacketUtils.FLAG_ACK, currentWindow(s)
            )
        )
    }

    private fun close(s: Session, rst: Boolean) {
        s.lock.withLock {
            if (s.closed) return
            s.closed = true
            s.cond.signalAll()
        }
        sessions.remove(s.key, s)
        s.queue.offer(Chunk(null, false, true))
        try { s.socket?.close() } catch (_: Exception) {}
        if (rst && s.connected) {
            writeTun(
                PacketUtils.buildTcp(
                    s.serverIp, s.clientIp, s.serverPort, s.clientPort,
                    s.sndNext, s.rcvNext, PacketUtils.FLAG_RST or PacketUtils.FLAG_ACK, 0
                )
            )
        }
    }

    fun cleanup() {
        val now = System.currentTimeMillis()
        for (s in sessions.values) {
            if (now - s.lastActive > IDLE_MS) close(s, true)
        }
    }

    fun shutdown() {
        for (s in sessions.values) close(s, false)
        sessions.clear()
        pool.shutdownNow()
        watchdog.shutdownNow()
    }
}
